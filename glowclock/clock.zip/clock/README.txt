Most of the instructions are the same as in the original, except calibration (see calibration.txt) and you'll also need another button (between pin 6 and ground) for displaying the date.

I adjusted the arm length/servo position constants, but these can vary slightly depending on your printer so you might want to re-measure them yourself. (see sizes.jpg)