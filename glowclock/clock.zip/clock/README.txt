Improved code for the glow in the dark clock
(https://www.thingiverse.com/thing:2833916)

I assume you'll have the clock built, the libraries downloaded, and the time set.

Calibration is different (read calibration.txt) and you'll also need another button (connecting pin 6 and ground) for displaying the date.

I adjusted the arm length/servo position constants, but these can vary slightly depending on your printer so you might want to re-measure them yourself. (see sizes.jpg)